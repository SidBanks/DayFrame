import { cloneExecutionRecord } from "../core/execution/executionRecord.js";
import {
  createCurrentActive as createActiveV3,
  readCurrentActive as readActiveV3,
  type CurrentActiveEnvelope as DayFrameActiveV3,
} from "./activeV4.js";
import {
  createDayFrameProfilesStorageV3,
  readProfilesV3,
  type DayFrameProfilesStorageV3,
} from "./dayFrameProfilesV3.js";
import {
  buildPlanDecisionRuntimeTarget,
  type PlanDecisionEnvelopeV1,
  type PlanDecisionRuntimeSnapshot,
} from "./planDecisionSurface.js";
import {
  buildExecutionHistoryRuntimeTarget,
  createExecutionHistoryEnvelope,
  type ExecutionHistoryRuntimeSnapshot,
  type QuarantinedExecutionHistoryComponent,
} from "./executionHistorySurface.js";
import {
  createPhysicalExecutionRecord,
  EXECUTION_HISTORY_METADATA_KEY,
  type ExecutionHistoryMetadata,
  type PhysicalExecutionRecord,
} from "./executionHistoryIndexedDb.js";
import {
  buildHistoricalPlanRuntimeTarget,
  type HistoricalPlanRuntimeSnapshot,
  type PhysicalHistoricalPlanBatchRecord,
  type PhysicalHistoricalPlanDayRecord,
} from "./historicalPlanSurface.js";
import type {
  ActiveLocalIngressStatus,
  DayFrameState,
  ProfileIngressStatus,
  StoreDesiredDurableCondition,
  SurfaceDurabilityStatus,
} from "./types.js";
import { validateGoalAuthority, type GoalAuthorityV1 } from "../core/goals/goal.js";
import type { GoalRuntimeSnapshot } from "./goalSurface.js";
import {
  validateMeasurementDefinitionAuthority,
  type GoalMeasurementDefinitionAuthorityV1,
} from "../core/measurement/measurementDefinition.js";
import type { MeasurementDefinitionSnapshot } from "./measurementDefinitionSurface.js";
import {
  validateProgressObservationAuthority,
  type GoalProgressObservationAuthorityV1,
} from "../core/progressObservation/progressObservation.js";
import type { ProgressObservationSnapshot } from "./progressObservationSurface.js";
import {
  validateGoalStructureAuthority,
  type GoalStructureAuthorityV1,
} from "../core/planning/goalStructure.js";
import type { GoalStructureRuntimeSnapshot } from "./goalStructureSurface.js";
import {
  validateGoalPlanningAuthority,
  type GoalPlanningAuthorityV2,
} from "../core/planning/goalDemand.js";
import type { CompositionAuthorityV1 } from "../core/planning/commitmentComposition.js";
import type { ProposalAuthorityV1 } from "../core/planning/proposal.js";
import {
  validateRealizationAuthority,
  type RealizationAuthorityV1,
} from "../core/planning/acceptedAllocationRealization.js";

export type ActiveRestoreRuntimeTarget = {
  activeState: DayFrameState;
  activeLocalIngressStatus: ActiveLocalIngressStatus;
  protectedActiveSource?: string;
  protectedActiveSourceKey?: string;
  durability: SurfaceDurabilityStatus;
  desired: StoreDesiredDurableCondition["activeState"];
};
export type ProfilesRestoreRuntimeTarget = {
  profiles: DayFrameState["savedProfiles"];
  profileIngressStatus: ProfileIngressStatus;
  quarantinedProfiles: unknown[];
  protectedProfileSource?: string;
  protectedProfileSourceKey?: string;
  durability: SurfaceDurabilityStatus;
  desired: StoreDesiredDurableCondition["profiles"];
};
export type ExecutionHistoryDurableRestorePayload = {
  records: PhysicalExecutionRecord[];
  quarantine: QuarantinedExecutionHistoryComponent[];
  metadata: ExecutionHistoryMetadata[];
  antiResurrection: "1";
};
export type HistoricalPlanDurableRestorePayload = {
  batches: PhysicalHistoricalPlanBatchRecord[];
  days: PhysicalHistoricalPlanDayRecord[];
};
export type RestoreDurablePayloadMap = {
  active: DayFrameActiveV3;
  profiles: DayFrameProfilesStorageV3;
  planDecisions: PlanDecisionEnvelopeV1;
  executionHistory: ExecutionHistoryDurableRestorePayload;
  historicalPlan: HistoricalPlanDurableRestorePayload;
  goals: GoalAuthorityV1;
  measurementDefinitions: GoalMeasurementDefinitionAuthorityV1;
  progressObservations: GoalProgressObservationAuthorityV1;
  goalStructure: GoalStructureAuthorityV1;
  goalPlanning: GoalPlanningAuthorityV2;
  composition: CompositionAuthorityV1;
  proposals: ProposalAuthorityV1;
  realizations: RealizationAuthorityV1;
};
export type RestoreRuntimeTargetMap = {
  active: ActiveRestoreRuntimeTarget;
  profiles: ProfilesRestoreRuntimeTarget;
  planDecisions: PlanDecisionRuntimeSnapshot;
  executionHistory: ExecutionHistoryRuntimeSnapshot;
  historicalPlan: HistoricalPlanRuntimeSnapshot;
  goals: GoalRuntimeSnapshot;
  measurementDefinitions: MeasurementDefinitionSnapshot;
  progressObservations: ProgressObservationSnapshot;
  goalStructure: GoalStructureRuntimeSnapshot;
  goalPlanning: {
    authority: GoalPlanningAuthorityV2;
    desired: GoalPlanningAuthorityV2;
    ingress: { status: "accepted" };
    durability: "durable";
  };
  composition: {
    authority: CompositionAuthorityV1;
    desired: CompositionAuthorityV1;
    ingress: { status: "accepted" };
    durability: "durable";
  };
  proposals: {
    authority: ProposalAuthorityV1;
    desired: ProposalAuthorityV1;
    ingress: { status: "accepted" };
    durability: "durable";
  };
  realizations: {
    authority: RealizationAuthorityV1;
    ingress: "ready";
  };
};

export function translateActiveRestorePayload(value: unknown) {
  try {
    const durable = readActiveV3(value);
    const activeState: DayFrameState = {
      ...structuredClone(durable.data),
      savedProfiles: [],
      preview: null,
    };
    const target: ActiveRestoreRuntimeTarget = {
      activeState,
      activeLocalIngressStatus: { status: "accepted", advisories: [] },
      durability: "durable",
      desired: "snapshot",
    };
    return {
      status: "valid" as const,
      durable: createActiveV3(structuredClone(durable.data)),
      target,
    };
  } catch {
    return { status: "invalid" as const, reason: "invalidActive" };
  }
}

export function translateProfilesRestorePayload(value: unknown) {
  try {
    const durable = readProfilesV3(value);
    const target: ProfilesRestoreRuntimeTarget = {
      profiles: structuredClone(durable.profiles),
      quarantinedProfiles: structuredClone(durable.quarantinedProfiles),
      profileIngressStatus: {
        status: "accepted",
        quarantinedEntryCount: durable.quarantinedProfiles.length,
      },
      durability: "durable",
      desired: "snapshot",
    };
    return {
      status: "valid" as const,
      durable: createDayFrameProfilesStorageV3(durable.profiles, durable.quarantinedProfiles),
      target,
    };
  } catch {
    return { status: "invalid" as const, reason: "invalidProfiles" };
  }
}

export function translatePlanDecisionRestorePayload(value: unknown) {
  const checked = buildPlanDecisionRuntimeTarget(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: structuredClone(checked.envelope),
        target: structuredClone(checked.target),
      }
    : checked;
}

export function translateExecutionHistoryRestorePayload(value: unknown) {
  if (
    !record(value) ||
    !exact(value, ["records", "quarantine", "metadata", "antiResurrection"]) ||
    !Array.isArray(value.records) ||
    !Array.isArray(value.quarantine) ||
    !Array.isArray(value.metadata) ||
    value.antiResurrection !== "1"
  )
    return { status: "invalid" as const, reason: "invalidExecutionHistoryPhysicalAuthority" };
  const records: unknown[] = [];
  for (const wrapper of value.records) {
    if (
      !record(wrapper) ||
      !exact(wrapper, [
        "recordId",
        "subjectId",
        "recordedAt",
        "plannedReferenceKey",
        "recordVersion",
        "record",
      ]) ||
      !record(wrapper.record)
    )
      return { status: "invalid" as const, reason: "invalidExecutionHistoryRecord" };
    const expected = createPhysicalExecutionRecord(wrapper.record as never);
    if (JSON.stringify(expected) !== JSON.stringify(wrapper))
      return { status: "invalid" as const, reason: "invalidExecutionHistoryRecord" };
    records.push(cloneExecutionRecord(wrapper.record as never));
  }
  const envelope = createExecutionHistoryEnvelope(records as never[], value.quarantine as never[]);
  const translated = buildExecutionHistoryRuntimeTarget(envelope);
  if (translated.status === "invalid") return translated;
  const translatedEnvelope = createExecutionHistoryEnvelope(
    translated.target.records,
    translated.target.quarantine,
  );
  if (JSON.stringify(translatedEnvelope) !== JSON.stringify(envelope))
    return { status: "invalid" as const, reason: "invalidExecutionHistoryAuthority" };
  if (
    value.metadata.length !== 1 ||
    !validExecutionMetadata(
      value.metadata[0],
      envelope.records.length,
      envelope.quarantinedComponents.length,
    )
  )
    return { status: "invalid" as const, reason: "invalidExecutionHistoryMetadata" };
  return {
    status: "valid" as const,
    durable: structuredClone(value) as ExecutionHistoryDurableRestorePayload,
    target: translated.target,
  };
}

export function translateHistoricalPlanRestorePayload(value: unknown) {
  const translated = buildHistoricalPlanRuntimeTarget(value);
  return translated.status === "valid"
    ? {
        status: "valid" as const,
        durable: structuredClone(value) as HistoricalPlanDurableRestorePayload,
        target: structuredClone(translated.target),
      }
    : translated;
}
export function translateGoalRestorePayload(value: unknown) {
  const checked = validateGoalAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: {
          authority: checked.authority,
          desired: checked.authority,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidGoals" };
}
export function translateMeasurementDefinitionRestorePayload(value: unknown) {
  const checked = validateMeasurementDefinitionAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: {
          authority: checked.authority,
          desired: checked.authority,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidMeasurementDefinitions" };
}
export function translateProgressObservationRestorePayload(value: unknown) {
  const checked = validateProgressObservationAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: {
          authority: checked.authority,
          desired: checked.authority,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidProgressObservations" };
}
export function translateGoalStructureRestorePayload(value: unknown) {
  const checked = validateGoalStructureAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: {
          authority: checked.authority,
          desired: checked.authority,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidGoalStructure" };
}
export function translateGoalPlanningRestorePayload(value: unknown) {
  const checked = validateGoalPlanningAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: {
          authority: checked.authority,
          desired: checked.authority,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidGoalPlanning" };
}

export function translateCompositionRestorePayload(value: unknown) {
  const valid =
    record(value) &&
    value.version === 1 &&
    Array.isArray(value.relationships) &&
    Array.isArray(value.decisions);
  return valid
    ? {
        status: "valid" as const,
        durable: structuredClone(value) as CompositionAuthorityV1,
        target: {
          authority: structuredClone(value) as CompositionAuthorityV1,
          desired: structuredClone(value) as CompositionAuthorityV1,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidComposition" };
}

export function translateProposalRestorePayload(value: unknown) {
  const valid =
    record(value) &&
    value.version === 1 &&
    Array.isArray(value.proposals) &&
    Array.isArray(value.candidates) &&
    Array.isArray(value.decisions) &&
    Array.isArray(value.acceptedAllocations);
  return valid
    ? {
        status: "valid" as const,
        durable: structuredClone(value) as ProposalAuthorityV1,
        target: {
          authority: structuredClone(value) as ProposalAuthorityV1,
          desired: structuredClone(value) as ProposalAuthorityV1,
          ingress: { status: "accepted" as const },
          durability: "durable" as const,
        },
      }
    : { status: "invalid" as const, reason: "invalidProposals" };
}

export function translateRealizationRestorePayload(value: unknown) {
  if (value === undefined)
    value = { version: 1, realizations: [], facts: [] } satisfies RealizationAuthorityV1;
  const checked = validateRealizationAuthority(value);
  return checked.status === "valid"
    ? {
        status: "valid" as const,
        durable: checked.authority,
        target: { authority: checked.authority, ingress: "ready" as const },
      }
    : { status: "invalid" as const, reason: "invalidRealizations" };
}

export const restoreTranslators = {
  active: translateActiveRestorePayload,
  profiles: translateProfilesRestorePayload,
  planDecisions: translatePlanDecisionRestorePayload,
  executionHistory: translateExecutionHistoryRestorePayload,
  historicalPlan: translateHistoricalPlanRestorePayload,
  goals: translateGoalRestorePayload,
  measurementDefinitions: translateMeasurementDefinitionRestorePayload,
  progressObservations: translateProgressObservationRestorePayload,
  goalStructure: translateGoalStructureRestorePayload,
  goalPlanning: translateGoalPlanningRestorePayload,
  composition: translateCompositionRestorePayload,
  proposals: translateProposalRestorePayload,
  realizations: translateRealizationRestorePayload,
};

function validExecutionMetadata(
  value: unknown,
  records: number,
  quarantine: number,
): value is ExecutionHistoryMetadata {
  return (
    record(value) &&
    exact(value, [
      "surface",
      "version",
      "authorityState",
      "legacyFingerprint",
      "recordCount",
      "quarantineCount",
    ]) &&
    value.surface === EXECUTION_HISTORY_METADATA_KEY &&
    value.version === 1 &&
    value.authorityState === "established" &&
    typeof value.legacyFingerprint === "string" &&
    value.recordCount === records &&
    value.quarantineCount === quarantine
  );
}
function exact(value: Record<string, unknown>, keys: string[]) {
  return Object.keys(value).length === keys.length && keys.every((key) => key in value);
}
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
