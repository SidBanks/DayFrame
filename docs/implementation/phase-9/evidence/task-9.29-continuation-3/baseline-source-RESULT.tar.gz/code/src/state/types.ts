import type { BlockRecurrence, BlockTemplate } from "../core/blocks/types.js";
import type { ManualCalendarEvent } from "../core/calendar/types.js";
import type { ShiftCycle } from "../core/cycles/types.js";
import type { GenerateSchedulePreviewResult } from "../core/engine/generateSchedulePreview.js";
import type { LocalDateString, ShiftDefinition } from "../core/shifts/types.js";
import type { TimeString, Weekday } from "../core/time/types.js";
import type { BackupValidationFailureCategory, DayFrameBackup } from "./dayFrameBackup.js";
import type { DayFrameBackupV3 } from "./dayFrameBackupV3.js";
import type { DayFrameBackupV4 } from "./dayFrameBackupV4.js";
import type { DayFrameBackupV5 } from "./dayFrameBackupV5.js";
import type { DayFrameBackupV6 } from "./dayFrameBackupV6.js";
import type { DayFrameBackupV7 } from "./dayFrameBackupV7.js";
import type { DayFrameBackupV8 } from "./dayFrameBackupV8.js";
import type { DayFrameBackupV9 } from "./dayFrameBackupV9.js";
import type { DayFrameBackupV10 } from "./dayFrameBackupV10.js";
import type { DayFrameBackupV11 } from "./dayFrameBackupV11.js";
import type { DayFrameBackupV12 } from "./dayFrameBackupV12.js";
import type { RealizationSurface } from "./realizationSurface.js";
import type {
  EffectivePreviewGenerationContextV1,
  PublicationRangeV1,
  ReviewScopeV1,
} from "../core/planning/planningScope.js";
import type { GoalSurface } from "./goalSurface.js";
import type { MeasurementDefinitionSurface } from "./measurementDefinitionSurface.js";
import type { ProgressObservationSurface } from "./progressObservationSurface.js";
import type { GoalStructureSurface } from "./goalStructureSurface.js";
import type { GoalPlanningSurface } from "./goalPlanningSurface.js";
import type { CompositionSurface } from "./compositionSurface.js";
import type { AllocationSurface } from "./allocationSurface.js";
import type { ProposalSurface } from "./proposalSurface.js";
import type { GoalProgressQueryV1 } from "../core/progress/manualQuantityProgress.js";
import type { GoalProgressQueryResultV1 } from "./goalProgressQuery.js";
import type { SuggestedFixFeedback } from "../core/friction/types.js";
import type { AuthoredSnapshotValidationResult } from "../core/authored/validateDayFrameAuthoredSetup.js";
import type { IncarnatedSource, SourceIncarnationId } from "../core/authored/sourceIncarnation.js";
import type {
  AcceptPlanDecisionInput,
  PlanDecisionId,
  PlanDecisionIdAllocator,
  PlanDecisionV1,
} from "../core/decisions/planDecision.js";
import type {
  AcceptPlanDecisionResult,
  PlanDecisionIngressStatus,
  PlanDecisionRecoveryResult,
  PlanDecisionRetryResult,
  QuarantinedPlanDecision,
  RemovePlanDecisionResult,
} from "./planDecisionSurface.js";
import type { ExecutionHistorySurface } from "./executionHistorySurface.js";
import type {
  HistoricalPlanSurface,
  HistoricalPlanPublicationResult,
} from "./historicalPlanSurface.js";
import type { MaterializePlanPublicationResult } from "../core/historicalPlan/materializePlanPublication.js";
import type { CapacityResultV1 } from "../core/planning/capacity.js";
import type { GoalFeasibilityResultV1 } from "../core/planning/goalFeasibility.js";
import type { PlanningFactId } from "../core/planning/planningFoundation.js";
import type { DayFrameReadinessApi } from "./dayFrameReadiness.js";
import type { HistoricalCompletionDistributionQueryV1 } from "../core/historicalIntelligence/completionDistribution.js";
import type { HistoricalSchedulingRealizationQueryV1 } from "../core/historicalIntelligence/schedulingRealization.js";
import type {
  HistoricalCompletionDistributionQueryResultV1,
  GoalActivityQueryResultV1,
  HistoricalSchedulingRealizationQueryResultV1,
} from "./historicalIntelligenceQuery.js";
import type { GoalActivityQueryV1 } from "../core/historicalIntelligence/goalActivity.js";

export type DayFrameSchedulingPreferences = {
  dayBoundaryStartTime: TimeString;
  weekStartsOn: Weekday;
};

export type PublishScheduleRangeInputV1 = {
  publicationRange: PublicationRangeV1;
  expectedSourceFingerprint: string;
  publishedAt: string;
};

export type PublishScheduleRangeFailureReasonV1 =
  | "publicationSourceUnqualified"
  | "contextReplaced"
  | "publicationBusy"
  | "pendingPublication"
  | "invalidPublicationRange"
  | "planningCoverageIncomplete"
  | "previewMissing"
  | "previewStale"
  | "previewRangeMismatch"
  | "frictionUnresolved"
  | "acceptedAllocationUnrealized"
  | "sourceChanged"
  | "queryFailure"
  | "materializationFailure"
  | "persistenceFailure"
  | "historicalPlanProtected"
  | "historicalPlanUnavailable"
  | "tryPreview"
  | "verificationFailedAfterCommit"
  | "commitStateUncertain"
  | "writeFailedBeforeCommit";

export type PublishScheduleRangeResultV1 = {
  readonly receipt?: import("./publicationReceipt.js").PublicationReceipt;
} & (
  | ({
      status: "published";
      batchId: string;
      publishedAt: string;
    } & import("./reviewSourceQualification.js").ReviewRequired)
  | ({ status: "alreadyPublished" } & import("./reviewSourceQualification.js").ReviewRequired)
  | {
      status: "rejected";
      reason: Exclude<PublishScheduleRangeFailureReasonV1, "publicationSourceUnqualified">;
    }
  | ({ status: "rejected" } & import("./reviewSourceQualification.js").PublicationSourceFailure)
);

export type DayFramePreviewRangePreset =
  | "threeDays"
  | "oneWeek"
  | "twoWeeks"
  | "oneMonth"
  | "custom";

export type DayFramePreviewRangeSource = "preset" | "custom" | "cycle";

export type DayFramePreviewRange = {
  source?: DayFramePreviewRangeSource;
  preset: DayFramePreviewRangePreset;
  startDate: LocalDateString;
  endDate: LocalDateString;
};

export type DayFramePreview = {
  result: GenerateSchedulePreviewResult;
  rangeStartDate: LocalDateString;
  rangeEndDate: LocalDateString;
  planningWindowStart: Date;
  planningWindowEnd: Date;
  generatedAt: string;
  revisedAt?: string;
  actionFeedback?: SuggestedFixFeedback;
  isStale: boolean;
  scopeMetadata?: EffectivePreviewGenerationContextV1;
};

export type DayFrameSavedProfile = {
  id: string;
  name: string;
  savedAt: string;
  data: DayFrameAuthoredPattern;
};

type RuntimeIncarnation = IncarnatedSource;
export type ActiveShiftDefinition = ShiftDefinition & RuntimeIncarnation;
export type ActiveShiftSegment = ShiftCycle["segments"][number] & RuntimeIncarnation;
export type ActiveShiftSequenceEntry = NonNullable<ShiftCycle["sequence"]>[number] &
  RuntimeIncarnation;
export type ActiveShiftCycle = Omit<ShiftCycle, "segments" | "sequence"> &
  RuntimeIncarnation & {
    segments: ActiveShiftSegment[];
    sequence?: ActiveShiftSequenceEntry[];
  };
export type ActiveBlockTemplate = BlockTemplate & RuntimeIncarnation;
export type ActiveBlockRecurrence = BlockRecurrence & RuntimeIncarnation;
export type ActiveManualCalendarEvent = ManualCalendarEvent & RuntimeIncarnation;

export type DayFrameState = {
  legacySleepConversions?: import("../core/sleep/legacySleepConversionRecord.js").LegacySleepConversionV1[];
  sleepRequirements?: import("../core/sleep/sleepRequirement.js").SleepRequirementV1[];
  schedulingPreferences: DayFrameSchedulingPreferences;
  previewRange: DayFramePreviewRange;
  shiftDefinitions: ActiveShiftDefinition[];
  shiftCycles: ActiveShiftCycle[];
  blockTemplates: ActiveBlockTemplate[];
  blockRecurrences: ActiveBlockRecurrence[];
  manualEvents: ActiveManualCalendarEvent[];
  savedProfiles: DayFrameSavedProfile[];
  preview: DayFramePreview | null;
};

export type DayFrameAuthoredSetup = Pick<
  DayFrameState,
  | "sleepRequirements"
  | "legacySleepConversions"
  | "schedulingPreferences"
  | "previewRange"
  | "shiftDefinitions"
  | "shiftCycles"
  | "blockTemplates"
  | "blockRecurrences"
  | "manualEvents"
>;

export type ActiveDayFrameAuthoredSetup = DayFrameAuthoredSetup;

export type DayFrameAuthoredPattern = {
  sleepRequirements?: import("../core/sleep/sleepRequirement.js").SleepRequirementPatternV1[];
  schedulingPreferences: DayFrameSchedulingPreferences;
  previewRange: DayFramePreviewRange;
  shiftDefinitions: ShiftDefinition[];
  shiftCycles: ShiftCycle[];
  blockTemplates: BlockTemplate[];
  blockRecurrences: BlockRecurrence[];
  manualEvents: ManualCalendarEvent[];
};

export type DayFrameStoreInitialState = Partial<DayFrameAuthoredPattern> &
  Partial<Pick<DayFrameState, "savedProfiles" | "preview">>;

export type GeneratePreviewActionInput = {
  rangeStartDate: LocalDateString;
  rangeEndDate: LocalDateString;
  planningWindowStart: Date;
  planningWindowEnd: Date;
  generatedAt: string;
  reviewScope?: ReviewScopeV1;
};

export type ApplyPreviewFixActionInput = {
  selectedFrictionPointId: string;
  selectedSuggestedFixId: string;
  revisedAt: string;
};

export type CommitAuthoredSetupInput = Pick<
  DayFrameAuthoredPattern,
  | "schedulingPreferences"
  | "previewRange"
  | "shiftDefinitions"
  | "shiftCycles"
  | "blockTemplates"
  | "blockRecurrences"
>;

export type AuthoredSourceKind =
  | "blockTemplate"
  | "blockRecurrence"
  | "manualEvent"
  | "shiftDefinition"
  | "shiftCycle"
  | "shiftSegment"
  | "shiftSequenceEntry";

export type AuthoredSourceReference = {
  sourceKind: AuthoredSourceKind;
  sourceId: string;
  parentSourceId?: string;
};

export type SourceLifecycleOperation = AuthoredSourceReference & {
  operation: "create" | "update" | "delete" | "replace";
};

export type AuthoredSetupLifecycleTransaction = {
  operations: SourceLifecycleOperation[];
};

export type CommitAuthoredSetupTransactionInput = {
  authoredSetup: CommitAuthoredSetupInput;
  lifecycle: AuthoredSetupLifecycleTransaction;
};

export type ManualEventLifecycleMutation =
  | { operation: "create" | "update" | "replace"; event: ManualCalendarEvent }
  | { operation: "delete"; sourceId: string };

export type PersistenceWriteOutcome =
  | { status: "persisted" }
  | { status: "pending" }
  | { status: "unavailable" }
  | { status: "serializationFailure" }
  | { status: "storageFailure" };

export type PersistenceRemovalOutcome =
  | { status: "removed" }
  | { status: "pending" }
  | { status: "unavailable" }
  | { status: "storageFailure" };

export type ActivePersistenceOutcome =
  | PersistenceWriteOutcome
  | { status: "blocked"; reason: "activeLocalRecovery" };

export type ActiveRemovalOutcome =
  | PersistenceRemovalOutcome
  | { status: "blocked"; reason: "activeLocalRecovery" };

export type PersistenceMutationResult = {
  state: DayFrameState;
  persistence: PersistenceWriteOutcome;
};

export type ActivePersistenceMutationResult = {
  state: DayFrameState;
  persistence: ActivePersistenceOutcome;
};

export type AppliedStoreMutationResult = ActivePersistenceMutationResult & {
  status: "applied";
};

export type StoreMutationResult =
  | AppliedStoreMutationResult
  | {
      status: "rejected";
      reason: "invalidAuthoredState";
      validation: Extract<AuthoredSnapshotValidationResult, { status: "invalid" }>;
    };

export type HistoricalIngressRecoveryRequiredResult = {
  status: "recoveryRequired";
  reason: "invalidAuthoredState";
  validation: Extract<AuthoredSnapshotValidationResult, { status: "invalid" }>;
};

export type ProfileLoadResult =
  | (ActivePersistenceMutationResult & {
      status: "loaded";
      advisories: AuthoredSnapshotValidationResult["advisories"];
    })
  | HistoricalIngressRecoveryRequiredResult
  | {
      status: "activationFailed";
      reason: "allocationFailure" | "activeValidationFailure";
    };

export type BackupImportResult =
  | (ActivePersistenceMutationResult & {
      status: "instantiatedFromLegacy" | "restored";
      advisories: AuthoredSnapshotValidationResult["advisories"];
    })
  | {
      status: "rejected";
      reason: BackupValidationFailureCategory | "allocationFailure" | "activeLocalRecovery";
    };

export type BackupV3ExportResult =
  | { status: "exported"; backup: DayFrameBackupV3; semanticFingerprint: string }
  | { status: "initializing" | "restoreBusy" }
  | {
      status: "protectedSurface";
      surface: "active" | "profiles" | "planDecisions" | "executionHistory" | "historicalPlan";
    }
  | { status: "validationFailure" | "exportFailure"; reason: string };

export type BackupV3ImportResult =
  | { status: "restoredV3"; semanticFingerprint: string }
  | {
      status:
        | "invalidBackup"
        | "unsupportedVersion"
        | "initializing"
        | "restoreBusy"
        | "protectedCurrentState"
        | "stagingFailure"
        | "sourceChanged"
        | "persistenceFailure"
        | "rollbackCompleted"
        | "recoveryRequired";
      surface?: string;
    };
export type BackupV4ExportResult =
  | { status: "exported"; backup: DayFrameBackupV4; semanticFingerprint: string }
  | Exclude<BackupV3ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "goals" };
export type BackupV4ImportResult =
  | { status: "restoredV4"; semanticFingerprint: string }
  | Exclude<BackupV3ImportResult, { status: "restoredV3" }>;
export type BackupV5ExportResult =
  | { status: "exported"; backup: DayFrameBackupV5; semanticFingerprint: string }
  | Exclude<BackupV4ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "measurementDefinitions" };
export type BackupV5ImportResult =
  | { status: "restoredV5"; semanticFingerprint: string }
  | Exclude<BackupV4ImportResult, { status: "restoredV4" }>;
export type BackupV6ExportResult =
  | { status: "exported"; backup: DayFrameBackupV6; semanticFingerprint: string }
  | Exclude<BackupV5ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "progressObservations" };
export type BackupV6ImportResult =
  | { status: "restoredV6"; semanticFingerprint: string }
  | Exclude<BackupV5ImportResult, { status: "restoredV5" }>;
export type BackupV7ExportResult =
  | { status: "exported"; backup: DayFrameBackupV7; semanticFingerprint: string }
  | Exclude<BackupV6ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "goalStructure" };
export type BackupV7ImportResult =
  | { status: "restoredV7"; semanticFingerprint: string }
  | Exclude<BackupV6ImportResult, { status: "restoredV6" }>;
export type BackupV8ExportResult =
  | { status: "exported"; backup: DayFrameBackupV8; semanticFingerprint: string }
  | Exclude<BackupV7ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "goalPlanning" };
export type BackupV8ImportResult =
  | { status: "restoredV8"; semanticFingerprint: string }
  | Exclude<BackupV7ImportResult, { status: "restoredV7" }>;
export type BackupV9ExportResult =
  | { status: "exported"; backup: DayFrameBackupV9; semanticFingerprint: string }
  | Exclude<BackupV8ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "composition" };
export type BackupV9ImportResult =
  | { status: "restoredV9"; semanticFingerprint: string }
  | Exclude<BackupV8ImportResult, { status: "restoredV8" }>;
export type BackupV10ExportResult =
  | { status: "exported"; backup: DayFrameBackupV10; semanticFingerprint: string }
  | Exclude<BackupV9ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "proposals" };
export type BackupV10ImportResult =
  | { status: "restoredV10"; semanticFingerprint: string }
  | Exclude<BackupV9ImportResult, { status: "restoredV9" }>;
export type BackupV11ExportResult =
  | { status: "exported"; backup: DayFrameBackupV11; semanticFingerprint: string }
  | Exclude<BackupV10ExportResult, { status: "exported" }>;
export type BackupV11ImportResult =
  | { status: "restoredV11"; semanticFingerprint: string }
  | Exclude<BackupV10ImportResult, { status: "restoredV10" }>;
export type BackupV12ExportResult =
  | { status: "exported"; backup: DayFrameBackupV12; semanticFingerprint: string }
  | Exclude<BackupV11ExportResult, { status: "exported" }>
  | { status: "protectedSurface"; surface: "realizations" };
export type BackupV12ImportResult =
  | { status: "restoredV12"; semanticFingerprint: string }
  | Exclude<BackupV11ImportResult, { status: "restoredV11" }>;

export type BackupV14ExportResult =
  | {
      status: "exported";
      backup: import("./dayFrameBackupV14.js").DayFrameBackupV14;
      semanticFingerprint: string;
    }
  | Exclude<BackupV13ExportResult, { status: "exported" }>;
export type BackupV14ImportResult =
  | { status: "restoredV14"; semanticFingerprint: string }
  | Exclude<BackupV13ImportResult, { status: "restoredV13" }>;
export type BackupV13ExportResult =
  | {
      status: "exported";
      backup: import("./dayFrameBackupV13.js").DayFrameBackupV13;
      semanticFingerprint: string;
    }
  | Exclude<BackupV12ExportResult, { status: "exported" }>;
export type BackupV13ImportResult =
  | { status: "restoredV13"; semanticFingerprint: string }
  | Exclude<BackupV12ImportResult, { status: "restoredV12" }>;
export type FullClearAuthorityResults = {
  active: ActiveRemovalOutcome;
  profiles: PersistenceRemovalOutcome;
  planDecisions: PersistenceRemovalOutcome;
  executionHistory: PersistenceRemovalOutcome;
  historicalPlan: PersistenceRemovalOutcome;
  goals: PersistenceRemovalOutcome;
  measurementDefinitions: PersistenceRemovalOutcome;
  progressObservations: PersistenceRemovalOutcome;
  goalStructure: PersistenceRemovalOutcome;
  goalPlanning: PersistenceRemovalOutcome;
  composition: PersistenceRemovalOutcome;
  proposals: PersistenceRemovalOutcome;
  realizations: PersistenceRemovalOutcome;
};

export type ClearLocalDataResult = {
  status: "cleared" | "partiallyCleared" | "failed";
  authorities: FullClearAuthorityResults;
  previewCleared: true;
  state: DayFrameState;
  /** Compatibility aliases; `authorities` is the canonical authority contract. */
  activeState: ActiveRemovalOutcome;
  profiles: PersistenceRemovalOutcome;
  planDecisions: PersistenceRemovalOutcome;
  executionHistory: PersistenceRemovalOutcome;
  historicalPlan: PersistenceRemovalOutcome;
  goals: PersistenceRemovalOutcome;
  measurementDefinitions: PersistenceRemovalOutcome;
  progressObservations: PersistenceRemovalOutcome;
  goalStructure: PersistenceRemovalOutcome;
  goalPlanning: PersistenceRemovalOutcome;
  composition: PersistenceRemovalOutcome;
  proposals: PersistenceRemovalOutcome;
  realizations: PersistenceRemovalOutcome;
  /** Compatibility aggregate; derived from `status`. */
  durability: "cleared" | "partiallyCleared" | "notCleared";
};

export type SurfaceDurabilityStatus =
  | "unknown"
  | "durable"
  | "pending"
  | "unavailable"
  | "serializationFailure"
  | "storageFailure";

export type StoreDurabilityStatus = {
  activeState: SurfaceDurabilityStatus;
  profiles: SurfaceDurabilityStatus;
};

export type DesiredDurableCondition = "snapshot" | "absent";

export type StoreDesiredDurableCondition = {
  activeState: DesiredDurableCondition;
  profiles: DesiredDurableCondition;
};

export type DurabilityRetryResult =
  | {
      status: "attempted";
      desiredCondition: "snapshot";
      persistence: PersistenceWriteOutcome;
    }
  | {
      status: "attempted";
      desiredCondition: "absent";
      persistence: PersistenceRemovalOutcome;
    }
  | {
      status: "notAttempted";
      reason: "unknown" | "alreadyDurable" | "serializationFailure" | "recoveryProtected";
    };

export type ActiveLocalIngressStatus =
  | {
      status: "noSource";
      reason: "missing" | "storageUnavailable" | "resolvedByAbandonment";
    }
  | {
      status: "accepted";
      advisories: AuthoredSnapshotValidationResult["advisories"];
    }
  | {
      status: "recoveryRequired";
      reason:
        | "readFailure"
        | "corruptJson"
        | "structurallyInvalid"
        | "unsupportedVersion"
        | "migrationFailure"
        | "invalidAuthoredState";
      activationBlocked: true;
      sourceReadable: boolean;
      sourcePreserved: boolean;
      migrationFailureDetail?: ActiveMigrationFailureDetail;
      validation?: Extract<AuthoredSnapshotValidationResult, { status: "invalid" }>;
    };

export type ActiveMigrationFailureDetail =
  | "parseFailure"
  | "validationFailure"
  | "allocationFailure"
  | "constructionFailure"
  | "serializationFailure"
  | "writeFailure"
  | "rereadFailure"
  | "rereadValidationFailure"
  | "verificationFailure";

export type ProfileIngressStatus =
  | { status: "noSource"; reason: "missing" | "storageUnavailable" }
  | { status: "accepted"; quarantinedEntryCount: number }
  | {
      status: "recoveryRequired";
      reason:
        | "readFailure"
        | "corruptJson"
        | "invalidCollection"
        | "unsupportedVersion"
        | "migrationFailure"
        | "invalidV2";
      failureDetail?:
        | "serializationFailure"
        | "writeFailure"
        | "rereadFailure"
        | "rereadValidationFailure"
        | "verificationFailure";
      sourcePreserved: boolean;
    };

export type QuarantinedProfileEntry = {
  quarantineId: string;
  reason: "invalidProfileEntry";
  originalProfileId?: string;
  originalProfileName?: string;
  raw: unknown;
};

export type ProfileMutationResult =
  | PersistenceMutationResult
  | {
      status: "blocked";
      reason: "profileRecovery";
      state: DayFrameState;
      persistence: { status: "notAttempted"; reason: "profileRecovery" };
    };

export type ProfileProtectedRecoveryResult =
  | { status: "resolved"; action: "replace" | "abandon"; persistence: { status: "persisted" } }
  | {
      status: "notResolved";
      action: "replace" | "abandon";
      persistence: Exclude<PersistenceWriteOutcome, { status: "persisted" }>;
    }
  | {
      status: "notAttempted";
      reason: "noProtectedSource" | "sourceUnreadable" | "sourceChanged" | "invalidCurrentState";
    };

export type QuarantineRemovalResult =
  | {
      status: "removed";
      quarantineId: string;
      persistence: PersistenceWriteOutcome;
      remainingCount: number;
    }
  | { status: "notAttempted"; reason: "missingEntry" | "profileRecovery" };

type ActiveLocalRecoveryNotAttempted = {
  status: "notAttempted";
  reason: "notRecoveryRequired" | "sourceUnreadable" | "sourceChanged";
};

export type ActiveLocalReplacementRecoveryResult =
  | {
      status: "resolved";
      resolution: "replaceWithCurrentState";
      persistence: { status: "persisted" };
      ingress: Extract<ActiveLocalIngressStatus, { status: "accepted" }>;
    }
  | {
      status: "notResolved";
      resolution: "replaceWithCurrentState";
      persistence: Exclude<PersistenceWriteOutcome, { status: "persisted" }>;
    }
  | ActiveLocalRecoveryNotAttempted
  | {
      status: "notAttempted";
      reason: "invalidReplacement";
      validation: Extract<AuthoredSnapshotValidationResult, { status: "invalid" }>;
    };

export type ActiveLocalAbandonmentRecoveryResult =
  | {
      status: "resolved";
      resolution: "abandonAndReset";
      persistence: { status: "removed" };
      state: DayFrameState;
      ingress: Extract<ActiveLocalIngressStatus, { status: "noSource" }>;
    }
  | {
      status: "notResolved";
      resolution: "abandonAndReset";
      persistence: Exclude<PersistenceRemovalOutcome, { status: "removed" }>;
    }
  | ActiveLocalRecoveryNotAttempted;

export type DayFrameStore = DayFrameReadinessApi & {
  initializeRestoreAuthority: () => Promise<void>;
  getState: () => DayFrameState;
  getDurabilityStatus: () => StoreDurabilityStatus;
  getActiveLocalIngressStatus: () => ActiveLocalIngressStatus;
  getProfileIngressStatus: () => ProfileIngressStatus;
  getQuarantinedProfiles: () => QuarantinedProfileEntry[];
  exportProtectedProfileSource: () =>
    | { status: "exported"; raw: string }
    | { status: "notAvailable"; reason: "noProtectedSource" | "sourceUnreadable" };
  exportQuarantinedProfile: (
    quarantineId: string,
  ) =>
    | { status: "exported"; entry: QuarantinedProfileEntry }
    | { status: "notAvailable"; reason: "missingEntry" };
  recheckProtectedProfileSource: () =>
    | "unchanged"
    | "sourceChanged"
    | "sourceUnreadable"
    | "noProtectedSource";
  getDesiredDurableCondition: () => StoreDesiredDurableCondition;
  retryActivePersistence: () => DurabilityRetryResult;
  retryProfilePersistence: () => DurabilityRetryResult;
  subscribeDurability: (listener: (status: StoreDurabilityStatus) => void) => () => void;
  subscribeActiveLocalIngress: (listener: (status: ActiveLocalIngressStatus) => void) => () => void;
  subscribeProfileIngress: (listener: (status: ProfileIngressStatus) => void) => () => void;
  subscribe: (listener: (state: DayFrameState) => void) => () => void;
  getPlanDecisions: () => PlanDecisionV1[];
  getQuarantinedPlanDecisions: () => QuarantinedPlanDecision[];
  getPlanDecisionDurabilityStatus: () => SurfaceDurabilityStatus;
  getPlanDecisionIngressStatus: () => PlanDecisionIngressStatus;
  subscribePlanDecisions: (listener: (decisions: PlanDecisionV1[]) => void) => () => void;
  subscribePlanDecisionDurability: (
    listener: (status: SurfaceDurabilityStatus) => void,
  ) => () => void;
  subscribePlanDecisionIngress: (
    listener: (status: PlanDecisionIngressStatus) => void,
  ) => () => void;
  trySleepPlacement: (
    input: import("../core/sleep/sleepCorrective.js").SleepPlacementTryInput & {
      ownerRange: import("../core/sleep/sleepResolution.js").SleepOwnerRange;
    },
  ) => import("../core/sleep/sleepCorrective.js").SleepPlacementTryResult;
  acceptPlanDecision: (input: AcceptPlanDecisionInput) => AcceptPlanDecisionResult;
  removePlanDecision: (id: PlanDecisionId) => RemovePlanDecisionResult;
  retryPlanDecisionPersistence: () => PlanDecisionRetryResult;
  removeQuarantinedPlanDecision: (quarantineId: string) => unknown;
  exportQuarantinedPlanDecision: (quarantineId: string) => unknown;
  exportProtectedPlanDecisionSource: () => unknown;
  recheckProtectedPlanDecisionSource: () =>
    | "unchanged"
    | "sourceChanged"
    | "sourceUnreadable"
    | "noProtectedSource";
  replaceProtectedPlanDecisionCheckpoint: () => PlanDecisionRecoveryResult;
  abandonProtectedPlanDecisionCheckpoint: () => PlanDecisionRecoveryResult;
  replaceProtectedActiveCheckpointWithCurrentState: () => ActiveLocalReplacementRecoveryResult;
  abandonProtectedActiveCheckpointAndReset: () => ActiveLocalAbandonmentRecoveryResult;
  replaceProtectedProfileCheckpointWithCurrentProfiles: () => ProfileProtectedRecoveryResult;
  abandonProtectedProfileCheckpoint: () => ProfileProtectedRecoveryResult;
  removeQuarantinedProfile: (quarantineId: string) => QuarantineRemovalResult;
  reviewLegacySleepConversion: (
    request: import("../core/sleep/legacySleepConversion.js").ConversionRequest,
  ) => Promise<import("../core/sleep/legacySleepConversion.js").ConversionReview>;
  convertLegacySleepToFirstClass: (
    input: import("../core/sleep/legacySleepConversion.js").ConfirmConversionInput,
  ) => Promise<
    | {
        status: "converted" | "alreadyConverted";
        conversion: import("../core/sleep/legacySleepConversionRecord.js").LegacySleepConversionV1;
      }
    | { status: "rejected"; reason: string }
  >;
  authorSleepRequirement: (input: {
    id: string;
    expectedRevision: number | null;
    expectedIncarnationId?: string;
    intent: import("../core/sleep/sleepRequirement.js").SleepRequirementIntentV1;
    recordedAt: string;
  }) =>
    | {
        status: "authored";
        requirement: import("../core/sleep/sleepRequirement.js").SleepRequirementV1;
        persistence: ActivePersistenceOutcome;
      }
    | { status: "protected" | "stale" }
    | { status: "invalid"; reason: string };
  deleteSleepRequirement: (input: {
    id: string;
    incarnationId: string;
    expectedRevision: number;
  }) =>
    | { status: "deleted"; persistence: ActivePersistenceOutcome }
    | { status: "protected" | "stale" };
  resolveRequiredSleep: (query: {
    ownerRange: import("../core/sleep/sleepResolution.js").SleepOwnerRange;
    budget?: number;
  }) => Promise<import("../core/sleep/sleepResolution.js").SleepResolutionV1>;
  queryEffectiveSleepRequirement: (
    ownerDay: import("../core/shifts/types.js").LocalDateString,
  ) =>
    | import("../core/sleep/sleepRequirement.js").EffectiveSleepRequirementResult
    | { status: "protected" };
  commitAuthoredSetupTransaction: (
    transaction: CommitAuthoredSetupTransactionInput,
  ) => StoreMutationResult;
  commitAuthoredSetup: (authoredSetup: CommitAuthoredSetupInput) => StoreMutationResult;
  setSchedulingPreferences: (
    schedulingPreferences: Partial<DayFrameSchedulingPreferences>,
  ) => StoreMutationResult;
  setPreviewRange: (previewRange: DayFramePreviewRange) => StoreMutationResult;
  setShiftDefinitions: (shiftDefinitions: ShiftDefinition[]) => StoreMutationResult;
  setShiftCycles: (shiftCycles: ShiftCycle[]) => StoreMutationResult;
  setBlockTemplates: (blockTemplates: BlockTemplate[]) => StoreMutationResult;
  setBlockRecurrences: (blockRecurrences: BlockRecurrence[]) => StoreMutationResult;
  setManualEvents: (manualEvents: ManualCalendarEvent[]) => StoreMutationResult;
  mutateManualEvent: (mutation: ManualEventLifecycleMutation) => StoreMutationResult;
  saveProfile: (input: { name: string; savedAt: string }) => ProfileMutationResult;
  loadProfile: (profileId: string) => ProfileLoadResult;
  deleteProfile: (profileId: string) => ProfileMutationResult;
  clearLocalData: () => Promise<ClearLocalDataResult>;
  exportBackup: (exportedAt: string) => Extract<DayFrameBackup, { version: 2 }>;
  importBackup: (backup: unknown) => BackupImportResult;
  exportBackupV3: (exportedAt: string) => Promise<BackupV3ExportResult>;
  importBackupV3: (backup: unknown) => Promise<BackupV3ImportResult>;
  importBackupFile: (
    backup: unknown,
  ) => Promise<
    | BackupImportResult
    | BackupV3ImportResult
    | BackupV4ImportResult
    | BackupV5ImportResult
    | BackupV6ImportResult
    | BackupV7ImportResult
    | BackupV8ImportResult
    | BackupV9ImportResult
    | BackupV10ImportResult
    | BackupV11ImportResult
    | BackupV14ImportResult
    | BackupV13ImportResult
    | BackupV12ImportResult
  >;
  exportBackupV4: (exportedAt: string) => Promise<BackupV4ExportResult>;
  importBackupV4: (backup: unknown) => Promise<BackupV4ImportResult>;
  exportBackupV5: (exportedAt: string) => Promise<BackupV5ExportResult>;
  importBackupV5: (backup: unknown) => Promise<BackupV5ImportResult>;
  exportBackupV6: (exportedAt: string) => Promise<BackupV6ExportResult>;
  importBackupV6: (backup: unknown) => Promise<BackupV6ImportResult>;
  exportBackupV7: (exportedAt: string) => Promise<BackupV7ExportResult>;
  importBackupV7: (backup: unknown) => Promise<BackupV7ImportResult>;
  exportBackupV8: (exportedAt: string) => Promise<BackupV8ExportResult>;
  importBackupV8: (backup: unknown) => Promise<BackupV8ImportResult>;
  exportBackupV9: (exportedAt: string) => Promise<BackupV9ExportResult>;
  importBackupV9: (backup: unknown) => Promise<BackupV9ImportResult>;
  exportBackupV10: (exportedAt: string) => Promise<BackupV10ExportResult>;
  importBackupV10: (backup: unknown) => Promise<BackupV10ImportResult>;
  exportBackupV11: (exportedAt: string) => Promise<BackupV11ExportResult>;
  importBackupV11: (backup: unknown) => Promise<BackupV11ImportResult>;
  exportBackupV14: (exportedAt: string) => Promise<BackupV14ExportResult>;
  importBackupV14: (backup: unknown) => Promise<BackupV14ImportResult>;
  exportBackupV13: (exportedAt: string) => Promise<BackupV13ExportResult>;
  importBackupV13: (backup: unknown) => Promise<BackupV13ImportResult>;
  exportBackupV12: (exportedAt: string) => Promise<BackupV12ExportResult>;
  importBackupV12: (backup: unknown) => Promise<BackupV12ImportResult>;
  generatePreview: (input: GeneratePreviewActionInput) => DayFrameState;
  publishScheduleRange: (
    input: PublishScheduleRangeInputV1,
  ) => Promise<PublishScheduleRangeResultV1>;
  applySuggestedFixToPreview: (input: ApplyPreviewFixActionInput) => DayFrameState;
  getLastHistoricalPlanPublicationResult: () =>
    | HistoricalPlanPublicationResult
    | Exclude<MaterializePlanPublicationResult, { status: "materialized" }>
    | undefined;
  getHistoricalCompletionDistribution: (
    query: HistoricalCompletionDistributionQueryV1,
  ) => Promise<HistoricalCompletionDistributionQueryResultV1>;
  getHistoricalSchedulingRealization: (
    query: HistoricalSchedulingRealizationQueryV1,
  ) => Promise<HistoricalSchedulingRealizationQueryResultV1>;
  getGoalActivity: (query: GoalActivityQueryV1) => Promise<GoalActivityQueryResultV1>;
  queryGoalProgress: (query: GoalProgressQueryV1) => GoalProgressQueryResultV1;
  queryGoalProgressObservationHistory: (
    goalId: import("../core/goals/goal.js").GoalId,
  ) => import("./goalProgressObservationHistoryQuery.js").GoalProgressObservationHistoryResult;
  recordSleepExecution: (
    input: import("./sleepExecutionCommand.js").SleepExecutionCommand,
  ) => ReturnType<typeof import("./sleepExecutionCommand.js").executeSleepCommand>;
  querySleepHistory: (
    query: import("./sleepHistoryQuery.js").SleepHistoryQuery,
  ) => ReturnType<typeof import("./sleepHistoryQuery.js").querySleepHistory>;
  queryToday: (
    query: import("./todayQuery.js").TodayQuery,
  ) => Promise<import("./todayQuery.js").TodayQueryResult>;
  querySelectedDayEvidence: (
    query: import("../core/productEvidence/selectedDayEvidence.js").SelectedDayEvidenceQuery,
  ) => ReturnType<typeof import("./selectedDayEvidenceQuery.js").querySelectedDayEvidence>;
  queryAcceptedPlanningEvidence: (
    query: import("../core/productEvidence/acceptedPlanningEvidence.js").AcceptedPlanningEvidenceQuery,
  ) => ReturnType<
    typeof import("./acceptedPlanningEvidenceQuery.js").queryAcceptedPlanningEvidence
  >;
  subscribePlanningReview: (listener: () => void) => () => void;
  queryPlanningReview: (input: {
    reviewScope: ReviewScopeV1;
    historyAsOf: string;
  }) => Promise<import("./planningScopeQuery.js").PlanningReviewReadModelV2>;
  queryCapacity: (query: {
    startUserDayDate: LocalDateString;
    endUserDayDateExclusive: LocalDateString;
  }) => Promise<
    | { status: "derived"; capacity: CapacityResultV1 }
    | {
        status: "unavailable";
        reason: "noPreview" | "outsidePreview" | "protectedAuthority";
      }
  >;
  queryCapacityForUserDay: (userDayDate: LocalDateString) => Promise<
    | { status: "derived"; capacity: CapacityResultV1 }
    | {
        status: "unavailable";
        reason: "noPreview" | "outsidePreview" | "protectedAuthority";
      }
  >;
  evaluateGoalDemandFeasibility: (input: {
    demandId: PlanningFactId;
    capacity: CapacityResultV1;
  }) => Promise<
    | { status: "evaluated"; feasibility: GoalFeasibilityResultV1 }
    | { status: "notFound" | "unknown" }
  >;
} & Omit<ExecutionHistorySurface, "clearExecutionHistory" | "getRuntimeAuthorityAdapter"> &
  AllocationSurface &
  Pick<
    HistoricalPlanSurface,
    | "initialize"
    | "retryPendingPublications"
    | "getHistoricalPlanDay"
    | "getHistoricalPlanRange"
    | "exportHistoricalPlan"
    | "abandonProtectedHistoricalPlan"
    | "getStatus"
    | "getPendingPublications"
    | "exportProtectedSource"
    | "recheckProtectedSource"
    | "subscribeStatus"
    | "subscribeHistory"
  > &
  Omit<GoalSurface, "clearGoals" | "getRuntimeAuthorityAdapter" | "replaceDurable"> &
  Omit<
    MeasurementDefinitionSurface,
    "clearMeasurementDefinitions" | "getRuntimeAuthorityAdapter" | "replaceDurable"
  > &
  Omit<
    ProgressObservationSurface,
    "clearProgressObservations" | "getRuntimeAuthorityAdapter" | "replaceDurable"
  > &
  Omit<GoalStructureSurface, "clearGoalStructure" | "getRuntimeAuthorityAdapter"> &
  Omit<GoalPlanningSurface, "clearGoalPlanning" | "getRuntimeAuthorityAdapter"> &
  Omit<CompositionSurface, "clearCompositionAuthority" | "getCompositionRuntimeAdapter"> &
  Omit<
    ProposalSurface,
    | "getProposalLifecycle"
    | "clearProposalAuthority"
    | "clearProposalForCoordinator"
    | "getProposalRuntimeAdapter"
  > &
  Omit<
    RealizationSurface,
    | "getRealizationProtectionEvidence"
    | "clearRealizationAuthority"
    | "clearRealizationForCoordinator"
    | "getRealizationRuntimeAdapter"
  >;

export type { SourceIncarnationId };
export type { PlanDecisionId, PlanDecisionIdAllocator, PlanDecisionV1 };
