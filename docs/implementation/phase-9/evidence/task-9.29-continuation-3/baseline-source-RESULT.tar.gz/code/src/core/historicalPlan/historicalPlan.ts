import type { BlockCategory } from "../blocks/types.js";
import type { DurableOccurrenceReference } from "../occurrences/durableOccurrenceReference.js";
import type { LocalDateString } from "../shifts/types.js";
import type { TimeString, Weekday } from "../time/types.js";
import { validatePlanPublicationBatch } from "./historicalPlanValidation.js";
import type { GoalId, GoalMeasurementPolicyReferenceV1, GoalStatus } from "../goals/goal.js";
import {
  realizedScheduleReference,
  type RealizedScheduleFactV1,
  type RealizedScheduleReferenceV1,
  type AcceptedScheduleRoleV1,
} from "../planning/realizedScheduleIdentity.js";

export const HISTORICAL_PLAN_SURFACE_VERSION = 1 as const;
export const PLAN_PUBLICATION_BATCH_VERSION = 1 as const;
export const HISTORICAL_PLAN_DAY_PUBLICATION_VERSION = 1 as const;
export const HISTORICAL_PLANNED_OCCURRENCE_SNAPSHOT_VERSION = 1 as const;
export const HISTORICAL_PLANNED_OCCURRENCE_SNAPSHOT_V2_VERSION = 2 as const;
export const HISTORICAL_REALIZED_SCHEDULE_SNAPSHOT_V3_VERSION = 3 as const;
export const HISTORICAL_PLAN_TITLE_MAX_LENGTH = 200;

export type PlanPublicationBatchId = string & { readonly __planPublicationBatchId: unique symbol };
export type PlanPublicationBatchIdAllocator = () => PlanPublicationBatchId;
export type HistoricalPlanSourceFamily =
  | "template"
  | "work"
  | "manualEvent"
  | "acceptedAllocation"
  | "sleepRequirement";
export type HistoricalPlanContext =
  | { state: "scheduled"; startsAt: string; endsAt: string }
  | { state: "unplaced" | "omitted" | "blocked" };

export type HistoricalPlannedOccurrenceSnapshotV1 = {
  version: typeof HISTORICAL_PLANNED_OCCURRENCE_SNAPSHOT_VERSION;
  reference: DurableOccurrenceReference;
  sourceFamily: Exclude<HistoricalPlanSourceFamily, "sleepRequirement">;
  title: string;
  category: BlockCategory;
  plan: HistoricalPlanContext;
  goals?: HistoricalGoalProvenanceV1[];
};
export type HistoricalOccurrenceTimingV2 = { kind: "allDay" } | { kind: "timed" };
export type HistoricalPlannedOccurrenceSnapshotV2 = Omit<
  HistoricalPlannedOccurrenceSnapshotV1,
  "version"
> & {
  version: typeof HISTORICAL_PLANNED_OCCURRENCE_SNAPSHOT_V2_VERSION;
  timing: HistoricalOccurrenceTimingV2;
  /** compositeId, parentOccurrenceId, pairingId, relationshipId, relationshipRevision */
  composition?: [string, string, string, string, number];
};
export type HistoricalRealizedScheduleSnapshotV3 = {
  version: typeof HISTORICAL_REALIZED_SCHEDULE_SNAPSHOT_V3_VERSION;
  reference: RealizedScheduleReferenceV1;
  sourceFamily: "acceptedAllocation";
  scheduleRole: AcceptedScheduleRoleV1;
  realizedSchedule: RealizedScheduleFactV1;
  title: string;
  category: BlockCategory;
  plan: { state: "scheduled"; startsAt: string; endsAt: string };
  timing: { kind: "timed" };
  goals?: HistoricalGoalProvenanceV1[];
};
export type HistoricalPlannedOccurrenceSnapshot =
  | import("../sleep/publishedSleep.js").HistoricalPublishedSleepSnapshotV4
  | HistoricalPlannedOccurrenceSnapshotV1
  | HistoricalPlannedOccurrenceSnapshotV2
  | HistoricalRealizedScheduleSnapshotV3;
export type HistoricalOccurrenceTimingSemantics =
  | { coverage: "unavailableLegacy" }
  | { coverage: "available"; kind: HistoricalOccurrenceTimingV2["kind"] };

export function historicalOccurrenceTimingSemantics(
  snapshot: HistoricalPlannedOccurrenceSnapshot,
): HistoricalOccurrenceTimingSemantics {
  return snapshot.version === HISTORICAL_PLANNED_OCCURRENCE_SNAPSHOT_V2_VERSION
    ? { coverage: "available", kind: snapshot.timing.kind }
    : snapshot.version === HISTORICAL_REALIZED_SCHEDULE_SNAPSHOT_V3_VERSION ||
        snapshot.version === 4
      ? { coverage: "available", kind: "timed" }
      : { coverage: "unavailableLegacy" };
}

export function createHistoricalRealizedScheduleSnapshot(input: {
  fact: RealizedScheduleFactV1;
  title: string;
  category: BlockCategory;
  goals?: HistoricalGoalProvenanceV1[];
}): HistoricalRealizedScheduleSnapshotV3 {
  return {
    version: 3,
    reference: realizedScheduleReference(input.fact),
    sourceFamily: "acceptedAllocation",
    scheduleRole: input.fact.scheduleRole,
    realizedSchedule: structuredClone(input.fact),
    title: input.title,
    category: input.category,
    plan: { state: "scheduled", startsAt: input.fact.startsAt, endsAt: input.fact.endsAt },
    timing: { kind: "timed" },
    ...(input.goals === undefined ? {} : { goals: structuredClone(input.goals) }),
  };
}
export type HistoricalGoalProvenanceV1 = {
  version: 1;
  goalId: GoalId;
  goalRevision: number;
  title: string;
  status: GoalStatus;
  measurementPolicy?: GoalMeasurementPolicyReferenceV1;
};
export type HistoricalGoalProvenanceCoverage = "available" | "unavailableLegacy";

/** Presence of `goals`, including an empty array, proves Goal-aware publication. */
export function historicalGoalProvenanceCoverage(
  snapshot: HistoricalPlannedOccurrenceSnapshot,
): HistoricalGoalProvenanceCoverage {
  return snapshot.goals === undefined ? "unavailableLegacy" : "available";
}

export type HistoricalPlanDayPublicationV1 = {
  version: typeof HISTORICAL_PLAN_DAY_PUBLICATION_VERSION | 2;
  sleepCoverage?: "notConfigured" | "notApplicable" | "satisfied";
  userDayDate: LocalDateString;
  dayBoundaryStartTime: TimeString;
  weekStartsOn: Weekday;
  utcOffsetMinutes: number;
  occurrences: HistoricalPlannedOccurrenceSnapshot[];
};

export type PlanPublicationBatchV1 = {
  surfaceVersion: typeof HISTORICAL_PLAN_SURFACE_VERSION;
  version: typeof PLAN_PUBLICATION_BATCH_VERSION;
  id: PlanPublicationBatchId;
  publishedAt: string;
  range: { startUserDayDate: LocalDateString; endUserDayDate: LocalDateString };
  days: HistoricalPlanDayPublicationV1[];
};

export type HistoricalPlanConstructionProviders = {
  allocateBatchId?: PlanPublicationBatchIdAllocator;
  now?: () => string;
};

export type CreatePlanPublicationBatchInput = Omit<
  PlanPublicationBatchV1,
  "surfaceVersion" | "version" | "id" | "publishedAt"
>;
export type CreatePlanPublicationBatchResult =
  | { status: "created"; batch: PlanPublicationBatchV1 }
  | {
      status: "invalidInput";
      issues: import("./historicalPlanValidation.js").HistoricalPlanValidationIssue[];
    }
  | { status: "allocationFailure"; reason: string };

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

export function isPlanPublicationBatchId(value: unknown): value is PlanPublicationBatchId {
  return typeof value === "string" && UUID_V4.test(value);
}

export function createPlanPublicationBatchId(): PlanPublicationBatchId {
  const randomUUID = globalThis.crypto?.randomUUID;
  if (!randomUUID)
    throw new Error("Cryptographic UUID generation is unavailable for PlanPublicationBatchId.");
  const value = randomUUID.call(globalThis.crypto);
  if (!isPlanPublicationBatchId(value))
    throw new Error("Cryptographic UUID generation returned an invalid PlanPublicationBatchId.");
  return value;
}

export function createPlanPublicationBatch(
  input: CreatePlanPublicationBatchInput,
  providers: HistoricalPlanConstructionProviders = {},
): CreatePlanPublicationBatchResult {
  try {
    const candidate: PlanPublicationBatchV1 = {
      surfaceVersion: HISTORICAL_PLAN_SURFACE_VERSION,
      version: PLAN_PUBLICATION_BATCH_VERSION,
      id: (providers.allocateBatchId ?? createPlanPublicationBatchId)(),
      publishedAt: (providers.now ?? (() => new Date().toISOString()))(),
      range: { ...input.range },
      days: input.days.map(cloneHistoricalPlanDay),
    };
    const validation = validatePlanPublicationBatch(candidate);
    return validation.status === "valid"
      ? { status: "created", batch: validation.batch }
      : { status: "invalidInput", issues: validation.issues };
  } catch (error) {
    return {
      status: "allocationFailure",
      reason: error instanceof Error ? error.message : "Unknown allocation failure",
    };
  }
}

export function cloneHistoricalPlanSnapshot(
  snapshot: HistoricalPlannedOccurrenceSnapshot,
): HistoricalPlannedOccurrenceSnapshot {
  if (snapshot.version === 3 || snapshot.version === 4) return structuredClone(snapshot);
  return {
    ...snapshot,
    reference: structuredClone(snapshot.reference),
    plan: { ...snapshot.plan },
    ...(snapshot.version === 2 ? { timing: { ...snapshot.timing } } : {}),
    ...(snapshot.version === 2 && snapshot.composition
      ? { composition: [...snapshot.composition] }
      : {}),
    ...(snapshot.goals === undefined ? {} : { goals: structuredClone(snapshot.goals) }),
  };
}

export function cloneHistoricalPlanDay(
  day: HistoricalPlanDayPublicationV1,
): HistoricalPlanDayPublicationV1 {
  return { ...day, occurrences: day.occurrences.map(cloneHistoricalPlanSnapshot) };
}

export function clonePlanPublicationBatch(batch: PlanPublicationBatchV1): PlanPublicationBatchV1 {
  return { ...batch, range: { ...batch.range }, days: batch.days.map(cloneHistoricalPlanDay) };
}
