import { withPublicationReceipt } from "./publicationReceipt.js";
import type { PublicationOrigin } from "./historicalPlanSurface.js";
import { capacityFingerprint } from "../core/planning/capacityFingerprint.js";
import { publicationBlockers } from "./publicationEligibility.js";
import {
  materializePlanPublication,
  type MaterializePlanPublicationResult,
} from "../core/historicalPlan/materializePlanPublication.js";
import type { GoalV1 } from "../core/goals/goal.js";
import type { ReviewScopeV1 } from "../core/planning/planningScope.js";
import { validateCanonicalUserDayRange } from "../core/planning/planningScope.js";
import { createReviewScope } from "../core/planning/reviewScope.js";
import type {
  HistoricalPlanPublicationResult,
  HistoricalPlanSurface,
} from "./historicalPlanSurface.js";
import type { PlanningReviewReadModelV1 } from "./planningScopeQuery.js";
import type {
  DayFrameAuthoredSetup,
  DayFrameState,
  PublishScheduleRangeInputV1,
  PublishScheduleRangeResultV1,
} from "./types.js";

export async function publishScheduleRangeV1(options: {
  input: PublishScheduleRangeInputV1;
  origin?: PublicationOrigin;
  getState: () => DayFrameState;
  getAuthoredSetup: () => DayFrameAuthoredSetup;
  getSleepAuthority?: () => import("../core/sleep/sleepFoundationalOccupancy.js").SleepFoundationAuthority;
  listGoals: () => GoalV1[];
  queryPlanningReview: (input: {
    reviewScope: ReviewScopeV1;
    historyAsOf: string;
  }) => Promise<PlanningReviewReadModelV1>;
  historicalPlan: Pick<HistoricalPlanSurface, "publishAtomically">;
  recordResult: (
    result:
      | HistoricalPlanPublicationResult
      | Exclude<MaterializePlanPublicationResult, { status: "materialized" }>,
  ) => void;
}): Promise<PublishScheduleRangeResultV1> {
  const input = structuredClone(options.input);
  const origin = options.origin;
  const result = await execute();
  return origin ? withPublicationReceipt(result, origin) : result;

  async function execute(): Promise<PublishScheduleRangeResultV1> {
    if (origin && !origin.isCurrent()) return { status: "rejected", reason: "contextReplaced" };
    if (validateCanonicalUserDayRange(input.publicationRange).status === "invalid")
      return { status: "rejected", reason: "invalidPublicationRange" };
    const currentAuthorityFingerprint = () =>
      capacityFingerprint({
        setup: options.getAuthoredSetup(),
        preview: options.getState().preview,
        goals: options.listGoals(),
        sleep: options.getSleepAuthority?.() ?? null,
      });
    const capturedAuthority = currentAuthorityFingerprint();
    const state = options.getState();
    const reviewScope = createReviewScope({
      kind: "custom",
      anchorUserDayDate: input.publicationRange.startUserDayDate,
      weekStartsOn: state.schedulingPreferences.weekStartsOn,
      source: "explicit",
      customRange: input.publicationRange,
    });
    let review: PlanningReviewReadModelV1;
    try {
      review = await options.queryPlanningReview({ reviewScope, historyAsOf: input.publishedAt });
    } catch {
      return {
        status: "rejected",
        reason: origin && !origin.isCurrent() ? "contextReplaced" : "queryFailure",
      };
    }
    if (origin && !origin.isCurrent()) return { status: "rejected", reason: "contextReplaced" };
    if (currentAuthorityFingerprint() !== capturedAuthority)
      return { status: "rejected", reason: "sourceChanged" };
    const blocker = publicationBlockers(review)[0];
    if (blocker) return { status: "rejected", reason: blocker };
    if (review.sourceFingerprint !== input.expectedSourceFingerprint)
      return { status: "rejected", reason: "sourceChanged" };
    const materialized = materializePlanPublication({
      authoredSetup: options.getAuthoredSetup(),
      ...(options.getSleepAuthority ? { sleepAuthority: options.getSleepAuthority() } : {}),
      preview: options.getState().preview,
      goals: options.listGoals(),
      publicationRange: input.publicationRange,
      providers: { now: () => input.publishedAt },
    });
    if (materialized.status !== "materialized") {
      options.recordResult(materialized);
      return { status: "rejected", reason: "materializationFailure" };
    }
    const persisted = await options.historicalPlan.publishAtomically(materialized.batch, {
      isCurrent: () => currentAuthorityFingerprint() === capturedAuthority,
      ...(origin ? { origin } : {}),
      recordResult: options.recordResult,
    });
    if (!origin) options.recordResult(persisted);
    if (persisted.status === "rejected") return { status: "rejected", reason: persisted.reason };
    if (persisted.status === "identicalPending")
      return { status: "rejected", reason: "pendingPublication" };
    if (persisted.status === "publishedAndDurable")
      return {
        status: "published",
        batchId: persisted.batch.id,
        publishedAt: persisted.batch.publishedAt,
      };
    if (persisted.status === "identicalNoOp") return { status: "alreadyPublished" };
    const reason =
      persisted.status === "publicationBlockedProtected"
        ? "historicalPlanProtected"
        : persisted.status === "verificationFailedAfterCommit"
          ? "verificationFailedAfterCommit"
          : persisted.status === "commitStateUncertain"
            ? "commitStateUncertain"
            : persisted.status === "writeFailedBeforeCommit"
              ? "writeFailedBeforeCommit"
              : persisted.status === "materializationUnavailable"
                ? "historicalPlanUnavailable"
                : "materializationFailure";
    return { status: "rejected", reason };
  }
}
