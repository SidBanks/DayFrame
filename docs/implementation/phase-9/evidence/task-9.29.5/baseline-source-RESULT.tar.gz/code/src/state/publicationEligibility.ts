import type { PlanningReviewReadModelV1 } from "./planningScopeQuery.js";

/** Shared, deterministic preconditions for Review and explicit publication. */
export function publicationBlockers(model: PlanningReviewReadModelV1) {
  const blockers: Array<
    | "planningCoverageIncomplete"
    | "previewMissing"
    | "previewStale"
    | "previewRangeMismatch"
    | "frictionUnresolved"
    | "acceptedAllocationUnrealized"
    | "historicalPlanProtected"
    | "historicalPlanUnavailable"
    | "tryPreview"
    | "materializationFailure"
  > = [];
  if (model.planningDataCoverage !== "complete") blockers.push("planningCoverageIncomplete");
  if (model.preview.availability !== "available") blockers.push("previewMissing");
  else {
    if (model.preview.freshness !== "current") blockers.push("previewStale");
    if (model.preview.coverage !== "covers") blockers.push("previewRangeMismatch");
    if (model.preview.revision === "try") blockers.push("tryPreview");
  }
  if (model.unresolvedFrictionCount > 0) blockers.push("frictionUnresolved");
  if (model.acceptedLiabilities.length > 0) blockers.push("acceptedAllocationUnrealized");
  if (model.publication.availability?.status === "protected")
    blockers.push("historicalPlanProtected");
  else if (model.publication.availability?.status !== "available")
    blockers.push("historicalPlanUnavailable");
  if (
    model.publication.materialization?.status !== "eligible" &&
    !blockers.some((code) =>
      ["previewMissing", "previewStale", "previewRangeMismatch", "tryPreview"].includes(code),
    )
  )
    blockers.push("materializationFailure");
  return blockers;
}
