import { useEffect, useState, type ReactElement } from "react";
import type { LocalDateString } from "../core/shifts/types.js";
import type { ReviewScopeV1 } from "../core/planning/planningScope.js";
import { createReviewScope } from "../core/planning/reviewScope.js";
import { publicationRangeFromReviewScope } from "../core/planning/reviewScope.js";
import type { PublishScheduleRangeResultV1 } from "../state/types.js";
import type { PlanningReviewReadModelV1 } from "../state/planningScopeQuery.js";
import { presentPlanningReview } from "./plannerReviewPresentation.js";
import type { RealizationCommandResultV1 } from "../core/planning/acceptedAllocationRealization.js";
import { realizationReasons, durationLabel } from "./planningResultCopy.js";
import { ScheduledGoalFacts } from "./ScheduledGoalFacts.js";
import { deriveScheduleReviewReadiness } from "./scheduleReviewReadiness.js";

export type ScheduleReviewQuery = (input: {
  reviewScope: ReviewScopeV1;
  historyAsOf: string;
}) => Promise<PlanningReviewReadModelV1>;

export function ScheduleReviewPanel(props: {
  startUserDayDate: LocalDateString;
  endUserDayDateExclusive: LocalDateString;
  weekStartsOn: "sunday" | "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday";
  historyAsOf: string;
  refreshKey?: unknown;
  goalNames?: Readonly<Record<string, string>>;
  onRetryRealization?: (id: string) => Promise<RealizationCommandResultV1>;
  query: ScheduleReviewQuery;
  unresolvedFrictionCount: number;
  onGeneratePreview: () => void;
  onOpenFriction: () => void;
  onAcceptProposal: (input: {
    proposalId: string;
    proposalRevision: number;
    optionId: string;
  }) => Promise<unknown>;
  onRejectProposal: (input: { proposalId: string; proposalRevision: number }) => Promise<unknown>;
  onPublish: (input: {
    publicationRange: ReturnType<typeof publicationRangeFromReviewScope>;
    expectedSourceFingerprint: string;
    publishedAt: string;
  }) => Promise<PublishScheduleRangeResultV1>;
  getPublishedAt: () => string;
}): ReactElement {
  const reviewScope = createReviewScope({
    kind: "custom",
    anchorUserDayDate: props.startUserDayDate,
    weekStartsOn: props.weekStartsOn,
    source: "navigation",
    customRange: {
      startUserDayDate: props.startUserDayDate,
      endUserDayDateExclusive: props.endUserDayDateExclusive,
    },
  });
  const [result, setResult] = useState<PlanningReviewReadModelV1 | "loading" | "error">("loading");
  const [refresh, setRefresh] = useState(0);
  const [pending, setPending] = useState<string | null>(null);
  const [mutationMessage, setMutationMessage] = useState("");
  const [publicationMessage, setPublicationMessage] = useState<{
    tone: "success" | "failure";
    text: string;
  } | null>(null);
  const [historyAsOf, setHistoryAsOf] = useState(props.historyAsOf);
  useEffect(() => {
    let current = true;
    setResult("loading");
    void props.query({ reviewScope, historyAsOf }).then(
      (value) => current && setResult(value),
      () => current && setResult("error"),
    );
    return () => {
      current = false;
    };
  }, [historyAsOf, props.query, refresh, reviewScope.id, props.refreshKey]);
  if (result === "loading")
    return (
      <section aria-busy="true" className="df-panel">
        Loading review readiness…
      </section>
    );
  if (result === "error")
    return (
      <section className="df-panel" role="alert">
        <h3>Review state unavailable</h3>
        <p>This period cannot be considered ready while planning truth is unavailable.</p>
      </section>
    );
  const readiness = deriveScheduleReviewReadiness({
    model: result,
    unresolvedFrictionCount: props.unresolvedFrictionCount,
    publicationRangeValid: true,
  });
  const presentation = presentPlanningReview(result);
  async function decide(id: string, action: () => Promise<unknown>) {
    setPending(id);
    setMutationMessage("");
    try {
      const outcome = await action();
      setMutationMessage(decisionMessage(outcome));
    } catch {
      setMutationMessage(
        "The decision result could not be confirmed. Review the refreshed acceptance and scheduling state before retrying.",
      );
    } finally {
      setPending(null);
      setRefresh((value) => value + 1);
    }
  }
  async function retryRealization(id: string) {
    if (!props.onRetryRealization) return;
    setPending(id);
    try {
      const outcome = await props.onRetryRealization(id);
      setMutationMessage(
        outcome.status === "realized" || outcome.status === "alreadyRealized"
          ? "Accepted work is scheduled. Refresh the schedule, review it, then publish explicitly."
          : `Acceptance is still saved; scheduling has not completed. ${outcome.reasons.map((reason) => realizationReasons[reason]).join(" ")}`,
      );
    } catch {
      setMutationMessage(
        "Acceptance is still saved. Scheduling could not complete; retry without accepting again.",
      );
    } finally {
      setPending(null);
      setRefresh((value) => value + 1);
    }
  }
  async function publish() {
    const publishedAt = props.getPublishedAt();
    let belongsToCurrentContext = () => true;
    setPending("publication");
    setPublicationMessage(null);
    try {
      const outcome = await props.onPublish({
        publicationRange: publicationRangeFromReviewScope(reviewScope),
        expectedSourceFingerprint:
          result === "loading" || result === "error" ? "" : result.sourceFingerprint,
        publishedAt,
      });
      belongsToCurrentContext = outcome.receipt?.isCurrent ?? belongsToCurrentContext;
      if (!belongsToCurrentContext()) return;
      if (outcome.status === "published" || outcome.status === "alreadyPublished") {
        setPublicationMessage({
          tone: "success",
          text:
            outcome.status === "published"
              ? "Schedule published. This immutable historical record does not lock future schedule changes."
              : "This exact publication was already recorded.",
        });
        setHistoryAsOf(publishedAt);
      } else {
        setPublicationMessage({ tone: "failure", text: publicationFailureMessage(outcome.reason) });
      }
    } catch {
      setPublicationMessage({
        tone: "failure",
        text: "The publication result could not be confirmed. History may have been saved. Do not publish again until its status can be verified.",
      });
    } finally {
      setPending(null);
      if (belongsToCurrentContext()) setRefresh((value) => value + 1);
    }
  }
  return (
    <section
      aria-labelledby="review-readiness-heading"
      className="df-panel df-schedule-review-summary"
    >
      <div className="df-screen-header">
        <p className="df-workflow-eyebrow">Review workflow</p>
        <h3 id="review-readiness-heading">Review readiness</h3>
        <p>
          {reviewScope.startUserDayDate} through {reviewScope.endUserDayDateExclusive} (exclusive)
        </p>
      </div>
      <dl className="df-summary-grid">
        <div>
          <dt>Planning data</dt>
          <dd>{result.planningDataCoverage}</dd>
        </div>
        <div>
          <dt>Preview coverage</dt>
          <dd>{result.preview.coverage}</dd>
        </div>
        <div>
          <dt>Preview freshness</dt>
          <dd>{result.preview.freshness}</dd>
        </div>
        <div>
          <dt>Schedule conflicts</dt>
          <dd>{props.unresolvedFrictionCount}</dd>
        </div>
        <div>
          <dt>Accepted awaiting realization</dt>
          <dd>{result.acceptedLiabilities.length}</dd>
        </div>
        <div>
          <dt>Proposals</dt>
          <dd>{result.proposals.length}</dd>
        </div>
      </dl>
      <div aria-live="polite">
        <h4>{readiness.publicationReady ? "Ready to publish" : "Not ready to publish"}</h4>
        {readiness.publicationReady ? (
          <p>
            This period satisfies the current derived publication-readiness policy. Publishing
            remains an explicit action.
          </p>
        ) : (
          <ul className="df-plain-list">
            {readiness.blockers.map((item) => (
              <li key={item.code}>{item.message}</li>
            ))}
          </ul>
        )}
        {readiness.warnings.map((item) => (
          <p className="df-warning-message" key={item.code}>
            {item.message}
          </p>
        ))}
        <p className="df-support">{presentation.publication.label}</p>
        {mutationMessage ? <p>{mutationMessage}</p> : null}
        {publicationMessage ? (
          <p role={publicationMessage.tone === "failure" ? "alert" : "status"}>
            {publicationMessage.text}
          </p>
        ) : null}
      </div>
      <div className="df-screen-actions">
        {readiness.blockers.some(
          (item) => item.action === "generatePreview" || item.action === "refreshPreview",
        ) ? (
          <button className="df-action-button" onClick={props.onGeneratePreview} type="button">
            {result.preview.availability === "unavailable" ? "Generate Preview" : "Refresh Preview"}
          </button>
        ) : null}
        {props.unresolvedFrictionCount ? (
          <button className="df-secondary-button" onClick={props.onOpenFriction} type="button">
            Resolve schedule conflicts
          </button>
        ) : null}
        <button
          className="df-action-button"
          disabled={!readiness.publicationReady || pending !== null}
          onClick={() => void publish()}
          type="button"
        >
          {pending === "publication"
            ? "Publishing…"
            : `${result.publication.publishedUserDays.length ? "Publish current schedule again" : "Publish schedule"}: ${reviewScope.startUserDayDate}–${reviewScope.endUserDayDateExclusive} (exclusive)`}
        </button>
      </div>
      {result.acceptedLiabilities.length ? (
        <section>
          <h4>Accepted authority awaiting realization</h4>
          <p>
            Accepted resource intent has not reached scheduled reality. Inspect or resolve the
            schedule before publication. Acceptance is saved; retry scheduling without accepting
            again.
          </p>
          {props.onRetryRealization
            ? [...new Set(result.acceptedLiabilities.map((item) => item.acceptedAllocationId))].map(
                (id) => (
                  <button
                    type="button"
                    className="df-secondary-button"
                    key={id}
                    disabled={pending !== null}
                    onClick={() => void retryRealization(id)}
                  >
                    Retry scheduling accepted work
                  </button>
                ),
              )
            : null}
        </section>
      ) : null}
      <ScheduledGoalFacts
        goalNames={props.goalNames ?? {}}
        facts={result.scheduledReality.map((item) => item.fact)}
      />
      {result.proposals.length ? (
        <section>
          <h4>Constructive Proposals</h4>
          <ul className="df-plain-list">
            {result.proposals.map(({ proposal }) => {
              const option =
                proposal.options.find((value) => value.preferred) ?? proposal.options[0];
              const key = `${proposal.id}:${proposal.revision}`;
              return (
                <li className="df-list-card" key={key}>
                  <strong>
                    Proposal for {proposal.horizon.startUserDayDate}–
                    {proposal.horizon.endUserDayDateExclusive}
                  </strong>
                  <span>
                    {proposal.options.length} bounded option
                    {proposal.options.length === 1 ? "" : "s"}. A Proposal does not own schedule
                    time.
                  </span>
                  {option ? (
                    <ul>
                      {(option.assignments ?? []).map((assignment) => (
                        <li key={assignment.demandProjectionId}>
                          {props.goalNames?.[assignment.goalId] ?? "Goal"} effort:{" "}
                          {durationLabel(assignment.assignedMinutes)}; unallocated:{" "}
                          {durationLabel(assignment.unmetMinutes)}.
                        </li>
                      ))}
                      {(option.claims ?? []).map((claim) => (
                        <li key={claim.id}>
                          {claim.role === "productive"
                            ? "Goal work"
                            : claim.role === "supportActivity"
                              ? "Support activity"
                              : "Protected Buffer (not an activity)"}
                          : {claim.userDayDate},{" "}
                          {new Date(claim.startsAt).toLocaleTimeString([], {
                            hour: "numeric",
                            minute: "2-digit",
                          })}
                          –
                          {new Date(claim.endsAt).toLocaleTimeString([], {
                            hour: "numeric",
                            minute: "2-digit",
                          })}
                        </li>
                      ))}
                    </ul>
                  ) : null}
                  <div className="df-screen-actions">
                    {option ? (
                      <button
                        disabled={pending !== null}
                        onClick={() =>
                          void decide(key, () =>
                            props.onAcceptProposal({
                              proposalId: proposal.id,
                              proposalRevision: proposal.revision,
                              optionId: option.id,
                            }),
                          )
                        }
                        type="button"
                      >
                        Accept preferred option
                      </button>
                    ) : null}
                    <button
                      disabled={pending !== null}
                      onClick={() =>
                        void decide(key, () =>
                          props.onRejectProposal({
                            proposalId: proposal.id,
                            proposalRevision: proposal.revision,
                          }),
                        )
                      }
                      type="button"
                    >
                      Reject Proposal
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ) : (
        <p className="df-support">No actionable Proposal intersects this Review Scope.</p>
      )}
    </section>
  );
}

function publicationFailureMessage(reason: string) {
  if (reason === "contextReplaced")
    return "The schedule context changed. Review the current schedule before publishing.";
  if (reason === "publicationBusy")
    return "Authority replacement is still finishing. Publication was not started. Review again after it finishes.";
  if (reason === "pendingPublication")
    return "This matching publication is pending persistence, not durably published. Its existing persistence status must be resolved before publishing again.";
  if (reason === "sourceChanged")
    return "The schedule changed since this review. Refresh the Preview and review again before publishing.";
  if (reason === "previewMissing" || reason === "previewStale" || reason === "previewRangeMismatch")
    return "Preview is no longer current for this range. Refresh it and review again.";
  if (reason === "frictionUnresolved") return "Resolve schedule conflicts before publishing.";
  if (reason === "acceptedAllocationUnrealized")
    return "Accepted scheduling authority must be realized before publishing.";
  if (reason === "historicalPlanProtected")
    return "Saved plan history is protected. Publication is blocked until it can be read safely.";
  if (reason === "historicalPlanUnavailable")
    return "Saved plan history is unavailable. Publication cannot proceed safely.";
  if (reason === "verificationFailedAfterCommit")
    return "The plan was written, but verification failed. History is protected; do not publish again until the saved plan can be verified.";
  if (reason === "commitStateUncertain" || reason === "persistenceFailure")
    return "The publication result could not be confirmed. History may have been saved. Do not publish again until its status can be verified.";
  if (reason === "writeFailedBeforeCommit")
    return "The publication transaction failed before committing. No new plan was saved.";
  if (reason === "tryPreview")
    return "Accept or discard the trial change, then refresh and review before publishing.";
  return "Publication could not proceed. Review the current blockers before publishing.";
}

function commandAccepted(value: unknown) {
  return (
    typeof value === "object" &&
    value !== null &&
    "status" in value &&
    (value as { status: string }).status === "accepted"
  );
}

function decisionMessage(value: unknown): string {
  if (!commandAccepted(value)) {
    const reason =
      value && typeof value === "object" && "reason" in value ? value.reason : undefined;
    return reason === "stale" || reason === "conflictingClaim"
      ? "This Proposal is out of date. Evaluate the planning opportunity again before accepting. No new acceptance was made."
      : "The decision was not recorded; existing authority is unchanged.";
  }
  if (
    value &&
    typeof value === "object" &&
    "value" in value &&
    value.value &&
    typeof value.value === "object" &&
    "realization" in value.value
  ) {
    const outcome = value.value.realization as RealizationCommandResultV1;
    return outcome.status === "realized" || outcome.status === "alreadyRealized"
      ? "Decision recorded. Accepted work is scheduled. Refresh the schedule and review it before explicit publication."
      : `Decision recorded. Acceptance is saved, but scheduling has not completed. ${(outcome.reasons ?? []).map((reason) => realizationReasons[reason]).join(" ")} Retry scheduling below without accepting again.`;
  }
  return "Decision recorded. Review state refreshed.";
}
